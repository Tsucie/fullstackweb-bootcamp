# Express Media Handling

1. Clone
2. Ganti `cloudinary.js` sesuai dengan konfigurasi-mu
3. Jalanin `node index.js`
