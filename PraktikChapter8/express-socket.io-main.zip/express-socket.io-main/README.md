# Express Socket.io

Jalanin aja pake `npm start` terus buka file `index.js` baca sampe abis!
